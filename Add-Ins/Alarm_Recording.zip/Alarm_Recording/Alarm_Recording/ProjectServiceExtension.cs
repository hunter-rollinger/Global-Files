﻿using System;
using Scada.AddIn.Contracts;
using Scada.AddIn.Contracts.AlarmMessageList;
using Scada.AddIn.Contracts.Variable;
using System.IO;


namespace Alarm_Recording
{
    /// <summary>
    /// Description of Project Service Extension.
    /// </summary>
    [AddInExtension("Export Recent Alarm", "This exports every alarm to a csv whenever it is received.", DefaultStartMode = DefaultStartupModes.Auto)]
    public class ProjectServiceExtension : IProjectServiceExtension
    {
        IProject _project = null;
        #region IProjectServiceExtension implementation
        bool alarmLatch = false;
        IOnlineVariableContainer var_collection = null;

        public void Start(IProject context, IBehavior behavior)
        {
            _project = context;
            _project.AlarmMessageList.AlarmEntryReceived += AlarmMesageList_EntryReceived;
            var_collection = _project.OnlineVariableContainerCollection["State_Vars"];
            if (var_collection == null)
            {
                var_collection = _project.OnlineVariableContainerCollection.Create("State_Vars");
            }
            var_collection.AddVariable("PLC_PackML_State");
            var_collection.Changed += Variables_Changed;
            var_collection.Activate();
        }

        public void Stop()
        {
            _project.AlarmMessageList.AlarmEntryReceived -= AlarmMesageList_EntryReceived;
            if (var_collection != null)
            {
                var_collection.Deactivate();
                var_collection.Changed -= Variables_Changed;
                var_collection = null;
            }
            _project = null;
        }

        private void Variables_Changed(object sender, Scada.AddIn.Contracts.Variable.ChangedEventArgs e)
        {
            Int32.TryParse(e.Variable.GetValue(0).ToString(), out int state);
            if (!(state == 2 || state == 7 || state == 8 || state == 9 || state == 1 || state == 0))
            {
                alarmLatch = false;
            }
        }

        private void Write_Alarm(string listEntry, string date)
        {
            date = date.Replace('/', '_');
            string filePath = _project.VariableCollection["Stop_Export_File_Path"].GetValue(0).ToString() + "Stops_" + date + ".csv";
            //string filePath = "C:\\ALARMS" + "\\Stops_" + date + ".csv";

            using (FileStream aFile = new FileStream(filePath, FileMode.Append, FileAccess.Write))
            using (StreamWriter sw = new StreamWriter(aFile))
            {
                sw.WriteLine(listEntry);
                sw.Close();
                aFile.Close();
            }

        }

        private void AlarmMesageList_EntryReceived(object sender, Scada.AddIn.Contracts.AlarmMessageList.AlarmEntryReceivedEventArgs e)
        {
            if (e.Item == null)
            {
                return;
            }
            else
            {
                IAlarmEntry alarmEntry = e.Item;
                short almClass = alarmEntry.ClassIndex;
                int state = Convert.ToInt32(_project.VariableCollection["PLC_PackML_State"].GetValue(0));
                 

                if (almClass == 1 && alarmLatch == false) //States are Stopped, Stopping, Aborting, Aborted, Clearing, Unknown
                {

                    string almIdentification = alarmEntry.Identification;
                    DateTime almReceived = alarmEntry.ReceivedTime;
                    string almText = alarmEntry.Text;




                    string s_alarmNumber = alarmEntry.VariableName.Replace("ALARMS[", "").Replace("]", "");

                    string listEntry = almReceived.ToString("t") + ',' + almReceived.ToString("d") + ',' + s_alarmNumber + ',' + almText;

                    Write_Alarm(listEntry, almReceived.ToString("d"));

                    alarmLatch = true;
                }

            }
        }
        #endregion
    }

    




}