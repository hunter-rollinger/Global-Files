﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            comboBox.ElementList = "1-One Pippa liisdmdjjdjdjd ddddd;2-Two;3-Three";
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            comboBox.ElementList = "1-One;2-Two;3-Three";
        }

        private void Button_2_Click(object sender, RoutedEventArgs e)
        {
            comboBox.ElementList = "1-Uno;2-Due;3-Tre";
        }

     

        private void Btn_Val1(object sender, RoutedEventArgs e)
        {
            comboBox.ElementSelected = 1;
        }

        private void Btn_Val2(object sender, RoutedEventArgs e)
        {
            comboBox.ElementSelected = 2;
        }

        private void Btn_Val3(object sender, RoutedEventArgs e)
        {
            comboBox.ElementSelected = 3;
        }
    }
}
