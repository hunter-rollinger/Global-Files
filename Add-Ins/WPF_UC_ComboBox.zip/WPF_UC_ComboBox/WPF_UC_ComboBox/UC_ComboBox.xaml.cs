﻿using System;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPF_UC_ComboBox
{
    /// <summary>
    /// Interaction logic for UserControl1.xaml
    /// </summary>
    public partial class UC_ComboBox : UserControl
    {

        //Studiare https://stackoverflow.com/questions/3775514/wpf-combobox-value-and-display-text/34679195

        private ObservableCollection<KeyValuePair<double, string>> _cmbElement = null;
        public ObservableCollection<KeyValuePair<double, string>> CmbElement
        {
            get { return _cmbElement; }
            set { _cmbElement = value;}
        }


        public double ElementSelected
        {
            get
            {
                return (double)GetValue(ElementSelectedDependencyProperty);
            }
            set
            {
                SetValue(ElementSelectedDependencyProperty, value);
            }
        }

        public static readonly DependencyProperty ElementSelectedDependencyProperty = DependencyProperty.Register("ElementSelected", typeof(double), typeof(UC_ComboBox), new FrameworkPropertyMetadata(0.0, new PropertyChangedCallback(OnElementSelectedDependencyPropertyChanged)));

        private static void OnElementSelectedDependencyPropertyChanged(DependencyObject source, DependencyPropertyChangedEventArgs e)
        {
            UC_ComboBox control = source as UC_ComboBox;
            if (control != null)
            {
                try
                {
                    control.ElementSelected = (double)e.NewValue;
                    KeyValuePair<double, string> elem = control.CmbElement[0];
                    foreach (KeyValuePair<double,string> kk in control.CmbElement)
                    {
                        if(kk.Key == control.ElementSelected)
                        {
                            elem = kk;
                            break;
                        }
                    }
                    control.comboBox.SelectedItem = elem;
                }
                catch (Exception)
                {

                }
            }
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                KeyValuePair<double, string> elem = (KeyValuePair<double, string>) comboBox.SelectedItem;

                ElementSelected = (double)elem.Key;
            }
            catch (Exception )
            {
                               
            }
        }


        public string ElementList
        {
            get
            {
                return (string)GetValue(ElementListDependencyProperty);
            }
            set
            {
                SetValue(ElementListDependencyProperty, value);
            }
        }

        public static readonly DependencyProperty ElementListDependencyProperty = DependencyProperty.Register("ElementList", typeof(string), typeof(UC_ComboBox), new FrameworkPropertyMetadata("", new PropertyChangedCallback(OnElementListDependencyPropertyChanged)));

        private static void OnElementListDependencyPropertyChanged(DependencyObject source, DependencyPropertyChangedEventArgs e)
        {
            UC_ComboBox control = source as UC_ComboBox;
            if (control != null)
            {
                try
                {
                   
                    string newelement = (string)e.NewValue;
                    string[] newelementslist = newelement.Split(new char[] { ';' });
                    control.CmbElement.Clear();
                    if(control.CmbElement == null)
                    {
                        control.CmbElement = new ObservableCollection<KeyValuePair<double, string>>();

                    }
                    foreach (string elem in newelementslist)
                    {
                        string[] lineelements = elem.Split(new char[] { '-' });

                        control.CmbElement.Add(new KeyValuePair<double, string>(Double.Parse(lineelements[0]), lineelements[1]));
                     }
                   
                    control.comboBox.SelectedValuePath = "Key";
                    control.comboBox.DisplayMemberPath = "Value";
                    KeyValuePair<double, string> kelem = control.CmbElement[0];
                    foreach (KeyValuePair<double, string> kk in control.CmbElement)
                    {
                        if (kk.Key == control.ElementSelected)
                        {
                            kelem = kk;
                            break;
                        }
                    }
                    control.comboBox.SelectedItem = kelem;
                    
                    CollectionViewSource.GetDefaultView(control.CmbElement).Refresh();
                    control.comboBox.UpdateLayout();
                }
                catch (Exception)
                {

                }
            }
        }

        private static int ActualStateUser;
        private static int ActualStateEnCond;
        private static int ActualStateDisCond;

        public double DisableDimmerUserLevel
        {
            get
            {
                return (double)GetValue(DisableDimmerUserLevelDependencyProperty);
            }
            set
            {
                SetValue(DisableDimmerUserLevelDependencyProperty, value);
            }
        }

        public static readonly DependencyProperty DisableDimmerUserLevelDependencyProperty = DependencyProperty.Register("DisableDimmerUserLevel", typeof(double), typeof(UC_ComboBox), new FrameworkPropertyMetadata(-1.0, new PropertyChangedCallback(OnDisableDimmerUserLevelDependencyPropertyChanged)));

        private static void OnDisableDimmerUserLevelDependencyPropertyChanged(DependencyObject source, DependencyPropertyChangedEventArgs e)
        {
            UC_ComboBox control = source as UC_ComboBox;
            if (control != null)
            {
                try
                {
                    int NewValue = Convert.ToInt32(e.NewValue);
                    if (ActualStateEnCond == 1 || ActualStateDisCond == 0 || NewValue == 0)
                    {
                        control.comboBox.IsEnabled = false;
                    }
                    else
                    {
                        control.comboBox.IsEnabled = true;
                    }
                    ActualStateUser = NewValue;
                    control.comboBox.UpdateLayout();
                }
                catch (Exception)
                {

                }
            }
        }

        public double EnableDimmerCond
        {
            get
            {
                return (double)GetValue(EnableDimmerCondDependencyProperty);
            }
            set
            {
                SetValue(EnableDimmerCondDependencyProperty, value);
            }
        }

        public static readonly DependencyProperty EnableDimmerCondDependencyProperty = DependencyProperty.Register("EnableDimmerCond", typeof(double), typeof(UC_ComboBox), new FrameworkPropertyMetadata(-1.0, new PropertyChangedCallback(OnEnableDimmerCondDependencyPropertyChanged)));

        private static void OnEnableDimmerCondDependencyPropertyChanged(DependencyObject source, DependencyPropertyChangedEventArgs e)
        {
            UC_ComboBox control = source as UC_ComboBox;
            if (control != null)
            {
                try
                {
                    int NewValue = Convert.ToInt32(e.NewValue);
                    if (ActualStateUser == 0 || ActualStateDisCond == 0 || NewValue == 1)
                    {
                        control.comboBox.IsEnabled = false;
                    }
                    else
                    {
                        control.comboBox.IsEnabled = true;
                    }
                    ActualStateEnCond = NewValue;
                    control.comboBox.UpdateLayout();
                }
                catch (Exception)
                {

                }
            }
        }

        public double DisableDimmerCond
        {
            get
            {
                return (double)GetValue(DisableDimmerCondDependencyProperty);
            }
            set
            {
                SetValue(DisableDimmerCondDependencyProperty, value);
            }
        }

        public static readonly DependencyProperty DisableDimmerCondDependencyProperty = DependencyProperty.Register("DisableDimmerCond", typeof(double), typeof(UC_ComboBox), new FrameworkPropertyMetadata(-1.0, new PropertyChangedCallback(OnDisableDimmerCondDependencyPropertyChanged)));

        private static void OnDisableDimmerCondDependencyPropertyChanged(DependencyObject source, DependencyPropertyChangedEventArgs e)
        {
            UC_ComboBox control = source as UC_ComboBox;
            if (control != null)
            {
                try
                {
                    int NewValue = Convert.ToInt32(e.NewValue);
                    if (ActualStateUser == 0 || ActualStateEnCond == 1 || NewValue == 0)
                    {
                        control.comboBox.IsEnabled = false;
                    }
                    else
                    {
                        control.comboBox.IsEnabled = true;
                    }
                    ActualStateDisCond = NewValue;
                    control.comboBox.UpdateLayout();
                }
                catch (Exception)
                {

                }
            }
        }

        public UC_ComboBox()
        {
            _cmbElement = new ObservableCollection<KeyValuePair<double, string>>();
            InitializeComponent();
            comboBox.DataContext = this;
            comboBox.SelectedIndex = 0;
            EnableDimmerCond = 0;
            DisableDimmerCond = 1;
            DisableDimmerUserLevel = 1;
        }       
    }
}
