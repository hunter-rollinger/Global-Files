﻿using System;
using Scada.AddIn.Contracts;
using Scada.AddIn.Contracts.AlarmMessageList;
using Scada.AddIn.Contracts.Variable;

namespace HMI_HelperService
{
    /// <summary>
    /// Description of Project Service Extension.
    /// </summary>
    [AddInExtension("COESIA HMI helper service", "Helper services for HMI", DefaultStartMode = DefaultStartupModes.Auto)]
    public class ProjectServiceExtension : IProjectServiceExtension
    {
        IProject _project = null;
        IOnlineVariableContainer _hmi_aux_olv = null;

        #region IProjectServiceExtension implementation

        public void Start(IProject context, IBehavior behavior)
        {
            _project = context;
            InitOLV();
            _project.AlarmMessageList.SelectionChanged += AlarmMessageList_SelectionChanged;
            _project.AlarmMessageList.AlarmEntryReceived += AlarmMesageList_EntryReceived;
        }

        public void Stop()
        {
            _project.AlarmMessageList.SelectionChanged -= AlarmMessageList_SelectionChanged;
            _project.AlarmMessageList.AlarmEntryReceived -= AlarmMesageList_EntryReceived;
            if (_hmi_aux_olv != null)
            {
                _hmi_aux_olv.Deactivate();
                _hmi_aux_olv.Changed -= _hmi_aux_olv_Changed;
                _hmi_aux_olv = null;
            }

            _project = null;
        }

        #endregion
        private void InitOLV()
        {
            //If variable in set change load description for keybord information
            _hmi_aux_olv = _project.OnlineVariableContainerCollection["HMI_AUX"];
            if (_hmi_aux_olv == null)
            {
                _hmi_aux_olv = _project.OnlineVariableContainerCollection.Create("HMI_AUX");
            }
            _hmi_aux_olv.AddVariable("[Project summary] Variable for set value input");
            _hmi_aux_olv.Changed += _hmi_aux_olv_Changed;
            _hmi_aux_olv.Activate();

        }

        private void _hmi_aux_olv_Changed(object sender, Scada.AddIn.Contracts.Variable.ChangedEventArgs e)
        {
            //If variable in set change load description for keybord information
            string varinmodify = e.Variable.GetValue(0).ToString();
            IVariable _var = _project.VariableCollection[varinmodify];
            if (_var != null)
            {
                string identification = _var.Identification;
                string translated_identification = _project.Translate(identification);
                _project.VariableCollection["Internal_VariableSetInput_Identification"].SetValue(0, translated_identification);
            }
        }

        private void AlarmMessageList_SelectionChanged(object sender, Scada.AddIn.Contracts.AlarmMessageList.SelectionChangedEventArgs e)
        {
            //Load selected information of Alarm Help
            if (e.SelectedItems == null)
            {
                return;
            }
            else
            {
                IAlarmEntry alarmEntry = e.SelectedItems[0];
                short almClass = alarmEntry.ClassIndex;
                string almIdentification = alarmEntry.Identification;
                DateTime almReceived = alarmEntry.ReceivedTime;
                DateTime almCleared = alarmEntry.ClearedTime;
                string almText = alarmEntry.Text;

                string categorytext = "";
                if (almClass == 1)
                    categorytext = "ALARMS[";
                else if (almClass == 2)
                    categorytext = "WARNINGS[";
                else if (almClass == 3)
                    categorytext = "MESSAGES[";
                
                string s_alarmNumber = alarmEntry.VariableName.Replace(categorytext, "").Replace("]", "");
                int alarmNumber = Int32.Parse(s_alarmNumber);

                string helpText = _project.VariableCollection["Internal_Alarm_HelpText[" + alarmNumber + "]"].GetValue(0).ToString();
                string helpTextTranslated = _project.Translate(helpText);
                _project.VariableCollection["AlarmSelected"].SetValue(0, alarmNumber);
                _project.VariableCollection["Internal_SelectedAlarm_ClassIndex"].SetValue(0, almClass);
                _project.VariableCollection["Internal_SelectedAlarm_Identification"].SetValue(0, almIdentification);
                _project.VariableCollection["Internal_SelectedAlarm_Text"].SetValue(0, almText);
                _project.VariableCollection["Internal_SelectedAlarm_TimeReceived"].SetValue(0, almReceived.ToString("t"));
                _project.VariableCollection["Internal_SelectedAlarm_DateReceived"].SetValue(0, almReceived.ToString("d"));
                if (almCleared.Date.Year == 1970)
                {
                    _project.VariableCollection["Internal_SelectedAlarm_TimeCleared"].SetValue(0, "");
                }
                else
                {
                    _project.VariableCollection["Internal_SelectedAlarm_TimeCleared"].SetValue(0, almCleared.ToString());
                }
                _project.VariableCollection["Internal_SelectedAlarm_HelpText"].SetValue(0, helpTextTranslated);

            }
        }

        private void AlarmMesageList_EntryReceived(object sender, Scada.AddIn.Contracts.AlarmMessageList.AlarmEntryReceivedEventArgs e)
        {
            if(e.Item == null)
            {
                return;
            }
            else
            {
                IAlarmEntry alarmEntry = e.Item;
                short almClass = alarmEntry.ClassIndex;
                if (almClass == 1) //Error - stop machine, execute popup
                {
                    string almIdentification = alarmEntry.Identification;
                    DateTime almReceived = alarmEntry.ReceivedTime;
                    DateTime almCleared = alarmEntry.ClearedTime;
                    string almText = alarmEntry.Text;

                    string s_alarmNumber = alarmEntry.VariableName.Replace("ALARMS[", "").Replace("]", "");
                    int alarmNumber = Int32.Parse(s_alarmNumber);

                    string helpText = _project.VariableCollection["Internal_Alarm_HelpText[" + alarmNumber + "]"].GetValue(0).ToString();
                    string helpTextTranslated = _project.Translate(helpText);
                    _project.VariableCollection["AlarmSelected"].SetValue(0, alarmNumber);
                    _project.VariableCollection["Internal_SelectedAlarm_ClassIndex"].SetValue(0, almClass);
                    _project.VariableCollection["Internal_SelectedAlarm_Identification"].SetValue(0, almIdentification);
                    _project.VariableCollection["Internal_SelectedAlarm_Text"].SetValue(0, almText);
                    _project.VariableCollection["Internal_SelectedAlarm_TimeReceived"].SetValue(0, almReceived.ToString("t"));
                    _project.VariableCollection["Internal_SelectedAlarm_DateReceived"].SetValue(0, almReceived.ToString("d"));
                    if (almCleared.Date.Year == 1970)
                    {
                        _project.VariableCollection["Internal_SelectedAlarm_TimeCleared"].SetValue(0, "");
                    }
                    else
                    {
                        _project.VariableCollection["Internal_SelectedAlarm_TimeCleared"].SetValue(0, almCleared.ToString());
                    }
                    _project.VariableCollection["Internal_SelectedAlarm_HelpText"].SetValue(0, helpTextTranslated);

                    //Set variable to trigger popup
                    _project.VariableCollection["TriggerDetailsAlarmFromPopup"].SetValue(0, 1);
                }
            }
        }
    }
}