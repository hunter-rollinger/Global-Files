﻿using System;
using System.Collections.Generic;
using Scada.AddIn.Contracts;
using Scada.AddIn.Contracts.Function;
using Scada.AddIn.Contracts.RecipeGroupManager;
using Scada.AddIn.Contracts.Variable;

namespace AddIn_TrendVariables
{
    /// <summary>
    /// Description of Project Service Extension.
    /// </summary>
    [AddInExtension("Trend Variables AddIn", "Dynamically Add Project Variables to Trend Screen", DefaultStartMode = DefaultStartupModes.Auto)]
    public class ProjectServiceExtension : IProjectServiceExtension
    {
        #region IProjectServiceExtension implementation

        IProject _project = null;
        IFunction switch_to_trend = null;
        IOnlineVariableContainer trendvar_collection = null;
        IRecipeGroup trendrecipegroup = null;

        List<IVariable> trendvars = new List<IVariable>();

        public void Start(IProject context, IBehavior behavior)
        {
            // enter your code which should be executed when starting the service for the SCADA Service Engine
            _project = context;

            trendvar_collection = _project.OnlineVariableContainerCollection["Trend_Vars"];
            if (trendvar_collection == null)
            {
                trendvar_collection = _project.OnlineVariableContainerCollection.Create("Trend_Vars");
            }
            trendvar_collection.AddVariable("LoadTrendVariables");
            trendvar_collection.Changed += Variables_Changed;
            trendvar_collection.Activate();

            switch_to_trend = _project.FunctionCollection["ss_Trends"];
        }

        private void Variables_Changed(object sender, ChangedEventArgs e)
        {
            Int32.TryParse(e.Variable.GetValue(0).ToString(), out int value);

            //clear out list before adding new variables
            trendvars.Clear();

            if (value == 1)
            {
                //execute function to fill trend curves
                if (switch_to_trend != null)
                {
                    //Get names of variables that have been added to trend recipe
                    trendrecipegroup = _project.RecipeGroupCollection["Trend"];
                    string[] names = trendrecipegroup.GetVariableNames();

                    foreach (string name in names)
                    {
                        IVariable temp = _project.VariableCollection[name];
                        trendvars.Add(temp);
                    }

                    int i = 0;
                    foreach (IVariable variable in trendvars)
                    {
                        switch_to_trend.CreateDynamicProperty("PictFilter.Curve[" + i + "]");
                        switch_to_trend.CreateDynamicProperty("PictFilter.Curve[" + i + "].VarInfo");
                        switch_to_trend.CreateDynamicProperty("PictFilter.Curve[" + i + "].YAxe");
                        switch_to_trend.SetDynamicProperty("PictFilter.Curve[" + i + "].IsShow", false);
                        switch_to_trend.SetDynamicProperty("PictFilter.Curve[" + i + "].HasYAxis", true);
                        switch_to_trend.SetDynamicProperty("PictFilter.Curve[" + i + "].GraphWidth", 4);
                        switch_to_trend.SetDynamicProperty("PictFilter.Curve[" + i + "].YAxe.IsGrid", true);
                        switch_to_trend.SetDynamicProperty("PictFilter.Curve[" + i + "].VarInfo.Variable", variable);
                        i++;
                    }

                    switch_to_trend.Execute();
                }
            }
        }

        public void Stop()
        {
            // enter your code which should be executed when stopping the service for the SCADA Service Engine
            if (trendvar_collection != null)
            {
                trendvar_collection.Deactivate();
                trendvar_collection.Changed -= Variables_Changed;
                trendvar_collection = null;
            }

            _project = null;
        }

        #endregion
    }
}