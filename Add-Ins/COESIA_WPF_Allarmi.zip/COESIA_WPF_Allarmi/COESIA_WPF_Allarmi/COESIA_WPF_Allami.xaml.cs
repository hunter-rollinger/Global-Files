﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System.Runtime.InteropServices;
using System.Timers;
using System.Collections.ObjectModel;

namespace COESIA_WPF_Allarmi
{
    /// <summary>
    /// Interaction logic for UserControl1.xaml
    /// </summary>
    public partial class COESIA_WPF_Allarmi_UC : UserControl
    {
        //zenon RT Reference
        private zenOn.Application zApplication = null;
        private zenOn.Project zRTProject = null;
        //zenon touch keyboard
        private System.Timers.Timer _timerFocus = null;
        private Application _app = null;
        System.Windows.Threading.Dispatcher _dispatcher = null;

        //Combobox alarm classes
        private List<AlarmClass> _alarmClasses = null;
        public List<AlarmClass> AlarmClasses
        {
            get
            {
                return _alarmClasses;
            }
            set
            {
                _alarmClasses = value;
            }
        }

        public COESIA_WPF_Allarmi_UC()
        {
            InitializeComponent();

            initZenonApplication();
            if (zRTProject != null)
            {
                Init();
            }
            else
            {
                InitOffline();
            }

            //User Control not in an WPF App -> We need to create a Application for the dispatcher
            if (Application.Current is null)
            {
                // Set an application in order to later access its dispatcher
                _app = new Application();
            }
            _dispatcher = Application.Current.Dispatcher;

        }

        //Conect to zenon RT and register the zenon Project
        public void initZenonApplication()
        {
            //We cannot log to zenon if we cannot connect
            try
            {
                // Check if zenOn is registered in the ROT.
                this.zApplication = Marshal.GetActiveObject("zenOn.Application") as zenOn.Application;

            }
            catch (COMException myExc)
            {
                System.Diagnostics.Debug.Print("Critical Error! The Runtime is not active! " + Environment.NewLine + "Error: " + myExc.Message);
                return;
            }

            zRTProject = zApplication.Projects().Item(0);
            if (zRTProject == null)
            {
                System.Diagnostics.Debug.Print("Error creating project instance!");
            }

        }

        private void Init()
        {
            //WPF Init component
            //The string is from zenon
            //We use the current Language of the HMI RT
            string _filter = zRTProject.String("@Filter");
            string _text = zRTProject.String("@Search");
            string _textWatermark = zRTProject.String("@Text to search");
            string _class =  zRTProject.String("@Alarm Type");
            string _alarmfrom =  zRTProject.String("@Show alarms from");
            string _to =  zRTProject.String("@to");

            string _all = zRTProject.String("@All");
            string _error = zRTProject.String("@Error");
            string _warning = zRTProject.String("@Warning");
            string _message = zRTProject.String("@Message");

            labelSearch.Content = _text;
            textSearchWatermark.Text = _textWatermark;
            labelClasses.Content = _class;

            _alarmClasses = new List<AlarmClass>();
            _alarmClasses.Add(new AlarmClass(_all));
            _alarmClasses.Add(new AlarmClass(_error));
            _alarmClasses.Add(new AlarmClass(_warning));
            _alarmClasses.Add(new AlarmClass(_message));

            cmbClasses.DataContext = this;
            cmbClasses.SelectedIndex = 0;
            cmbClasses.ItemsSource = AlarmClasses;
            cmbClasses.DisplayMemberPath = "Category";
            cmbClasses.SelectedValuePath = "Category";


            labelFrom.Content = _alarmfrom;
            dateFrom.SelectedDate = DateTime.Now;

            labelTo.Content = _to;
            dateTo.SelectedDate = DateTime.Now;

            btnApply.Content = _filter;


        }

        //Init WPF component if zenon RT is not connected -> Debug in VS
        private void InitOffline()
        {

            labelSearch.Content = "Search";
            labelClasses.Content = "Alarm Type";

            textSearchWatermark.Text = "Text to search";

            _alarmClasses = new List<AlarmClass>();
            _alarmClasses.Add(new AlarmClass("All"));
            _alarmClasses.Add(new AlarmClass("Error"));
            _alarmClasses.Add(new AlarmClass("Warning"));
            _alarmClasses.Add(new AlarmClass("Messagge"));


            cmbClasses.DataContext = this;
            cmbClasses.SelectedIndex = 0;
            cmbClasses.ItemsSource = AlarmClasses;
            cmbClasses.DisplayMemberPath = "Category";
            cmbClasses.SelectedValuePath = "Category";

            labelFrom.Content = "Alarm from";
            dateFrom.SelectedDate = DateTime.Now;

            labelTo.Content = "to";
            dateTo.SelectedDate = DateTime.Now;

            btnApply.Content = "Filter";


        }

        //Filter button logic
        private void BtnApply_Click(object sender, RoutedEventArgs e)
        {
            //Only for VS debug
            if(zRTProject == null)
            {
                System.Diagnostics.Debug.WriteLine("Filter button pressed");
                return;
            }

            //To filter alarm history : take the screen switch function -> Modify parameter -> Execute function
            zenOn.RtFunction fct = zRTProject.RtFunctions().Item("ss_HistoricalAlarm");
            //Parameter for text search
            if (textSearch.Text != "Text" && textSearch.Text != "")
            { 
                fct.DynProperties["PictFilter[0].TextFilter.IsFilterActive"] = true;
                fct.DynProperties["PictFilter[0].TextFilter.Expression"] = textSearch.Text;
                fct.DynProperties["PictFilter[0].TextFilter.IsMatchCase"] = false;
                fct.DynProperties["PictFilter[0].TextFilter.IsSubFind"] = true;
            }
            else
            {
                fct.DynProperties["PictFilter[0].TextFilter.IsFilterActive"] = false;
                fct.DynProperties["PictFilter[0].TextFilter.Expression"] = "";
                fct.DynProperties["PictFilter[0].TextFilter.IsMatchCase"] = false;
                fct.DynProperties["PictFilter[0].TextFilter.IsSubFind"] = false;

            }
            //Parameter for Alarm Class search
            if (cmbClasses.SelectedIndex==0)
            {
                fct.DynProperties["PictFilter[0].Classes"] = "0;";
            }
            if (cmbClasses.SelectedIndex == 1)
            {
                fct.DynProperties["PictFilter[0].Classes"] = "1;1;";
            }
            if (cmbClasses.SelectedIndex == 2)
            {
                fct.DynProperties["PictFilter[0].Classes"] = "1;2;";
            }
            if (cmbClasses.SelectedIndex == 3)
            {
                fct.DynProperties["PictFilter[0].Classes"] = "1;3;";
            }

            //Parameter for time search -> 12 = Absolute time
            fct.DynProperties["PictFilter[0].TimeFilter.TimeFormat"]= 12;

            //Time search : time start is 00:00/Time end is 23:59 -> HMI select only the day
            DateTime? dp_from = dateFrom.SelectedDate;
            DateTime? dp_to   = dateTo.SelectedDate;
            if(dp_from == null)
            {
                dp_from = new DateTime(1970, 1, 1);
            }
            if(dp_to==null)
            {
                dp_to = DateTime.UtcNow;
            }

            DateTime from = new DateTime(dp_from.Value.Year, dp_from.Value.Month, dp_from.Value.Day, 0, 0, 0);
            DateTime to = new DateTime(dp_to.Value.Year, dp_to.Value.Month, dp_to.Value.Day,23, 59, 59);

            //zenon internal time is Unix Time -> second from 01/01/1970 00:00:00
            Int32 startunix = (Int32)(from.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
            Int32 endunix = (Int32)(to.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;

            fct.DynProperties["PictFilter[0].TimeFilter.ARVTime1"] = startunix;
            fct.DynProperties["PictFilter[0].TimeFilter.ARVTime2"] = endunix;

            //execute the function -> Alarm History filter with WPF parameter
            fct.Start();
        }

        //Trick : in WPF we need the Touch keyboard -> We use zenon
        //We open the keyboard, wait a little time and then set the focus another time in the text search field
        private void TextSearch_GotFocus(object sender, RoutedEventArgs e)
        {
            if(zRTProject!= null)
            { 
                zRTProject.RtFunctions().Item("ss_Keyboard_wpf").Start();
                _timerFocus = new Timer(1500.0);
                _timerFocus.Elapsed += _timerFocus_Elapsed;
                _timerFocus.Enabled = true;
            }

        }

        private void _timerFocus_Elapsed(object sender, ElapsedEventArgs e)
        {
            _timerFocus.Enabled = false;
            _timerFocus.Elapsed -= _timerFocus_Elapsed;
            _timerFocus = null;
            _dispatcher.Invoke((Action)delegate
            {
                textSearch.Focus();
            });

        }
    }

    //Internal Class for the ComboBox Alarm Category
    public class AlarmClass
    {
        private string _category;
        public string Category
        {
            get
            {
                return _category;
            }
            set
            {
                _category = value;
            }
        }

        public AlarmClass(string cat)
        {
            Category = cat;
        }
    }

}
