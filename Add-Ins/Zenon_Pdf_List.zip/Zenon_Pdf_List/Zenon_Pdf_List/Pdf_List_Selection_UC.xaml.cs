﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Zenon_Pdf_List
{
    /// <summary>
    /// Interaction logic for UserControl1.xaml
    /// </summary>
    public partial class Pdf_List_Selection_UC : UserControl
    {
        private zenOn.Application zApplication = null;
        private zenOn.Project zRTProject = null;

        public Pdf_List_Selection_UC()
        {
            InitializeComponent();
            initZenonApplication();
        }

        //Conect to zenon RT and register the zenon Project
        public void initZenonApplication()
        {
            //We cannot log to zenon if we cannot connect
            try
            {
                // Check if zenOn is registered in the ROT.
                this.zApplication = Marshal.GetActiveObject("zenOn.Application") as zenOn.Application;

            }
            catch (COMException myExc)
            {
                System.Diagnostics.Debug.Print("Critical Error! The Runtime is not active! " + Environment.NewLine + "Error: " + myExc.Message);
                return;
            }

            zRTProject = zApplication.Projects().Item(0);
            if (zRTProject == null)
            {
                System.Diagnostics.Debug.Print("Error creating project instance!");
            }

        }

        public String PDF_Path
        {
            get
            {
                return (String)GetValue(PDF_PathDependencyProperty);
            }
            set
            {
                SetValue(PDF_PathDependencyProperty, value);
                GetSetPDFFileList();
            }
        }

        public static readonly DependencyProperty PDF_PathDependencyProperty = DependencyProperty.Register("PDF_Path", typeof(String), typeof(Pdf_List_Selection_UC), new FrameworkPropertyMetadata("", new PropertyChangedCallback(OnPDF_PathDependencyPropertyChanged)));

        private static void OnPDF_PathDependencyPropertyChanged(DependencyObject source, DependencyPropertyChangedEventArgs e)
        {
            Pdf_List_Selection_UC control = source as Pdf_List_Selection_UC;
            if(control != null)
            {
                try
                {
                    control.PDF_Path = (String)e.NewValue;
                }catch(Exception ex)
                {
                    ;
                }
            }
        }

        public String PDF_Selected
        {
            get
            {
                return (String)GetValue(PDF_SelectedDependencyProperty);
            }
            set
            {
                SetValue(PDF_SelectedDependencyProperty, value);
            }
        }

        public static readonly DependencyProperty PDF_SelectedDependencyProperty = DependencyProperty.Register("PDF_Selected", typeof(String), typeof(Pdf_List_Selection_UC), new FrameworkPropertyMetadata("", new PropertyChangedCallback(OnPDF_SelectedDependencyPropertyChanged)));

        private static void OnPDF_SelectedDependencyPropertyChanged(DependencyObject source, DependencyPropertyChangedEventArgs e)
        {
            Pdf_List_Selection_UC control = source as Pdf_List_Selection_UC;
            if (control != null)
            {
                try
                {
                    control.PDF_Selected = (String)e.NewValue;
                }
                catch (Exception ex)
                {
                    ;
                }
            }
        }

        private void PDFListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            zenOn.RtFunction func = zRTProject.RtFunctions().Item("ss_Manuals_HTML");
            string _selected = "";
            try
            {
                if(PDFListBox.SelectedItems[0] != null)
                {
                    _selected = PDFListBox.SelectedItems[0].ToString();
                    PDF_Selected = System.IO.Path.Combine(PDF_Path,_selected);

                    func.Start();
                }
            }catch(Exception)
            {
                ;
            }
        }

        private void PDFListBox_Loaded(object sender, RoutedEventArgs e)
        {
            

        }

        private void GetSetPDFFileList()
        {
            string[] _files = null;
            if (System.IO.Directory.Exists(PDF_Path))
            {
                PDFListBox.Items.Clear();
                _files = System.IO.Directory.GetFiles(PDF_Path, "*.pdf");
                foreach (string file in _files)
                {
                    PDFListBox.Items.Add(System.IO.Path.GetFileName(file));
                }
            }
        }
    }
}
