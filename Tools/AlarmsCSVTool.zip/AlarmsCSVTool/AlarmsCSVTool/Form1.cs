﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Excel = Microsoft.Office.Interop.Excel;

namespace AlarmsCSVTool
{
    public partial class Form1 : Form
    {
        private OpenFileDialog fileDialog;
        private string sourcepath = "";
        private string destpath = "";
        private string language = "";
        private bool issourcebitwise = false;

        public Form1()
        {
            InitializeComponent();
            fileDialog = new OpenFileDialog();
            fileDialog.Filter = "Excel or CSV|*.xls;*.xlsx;*.csv";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (fileDialog.ShowDialog() == DialogResult.OK)
            {
                textBox1.Text = fileDialog.FileName;
                sourcepath = fileDialog.FileName;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (fileDialog.ShowDialog() == DialogResult.OK)
            {
                textBox2.Text = fileDialog.FileName;
                destpath = fileDialog.FileName;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox5.Text = "";

            Excel.Application sourceapp;
            Excel.Workbook sourcebook = null;
            Excel.Worksheet sourcesheet;
            Excel.Application destapp;
            Excel.Workbook destbook = null;
            Excel.Worksheet destsheet;

            sourcepath = textBox1.Text;
            destpath = textBox2.Text;
            string sourcematchtext = textBox3.Text; //string to find from export
            string destmatchtext = textBox4.Text;
            string alarmnamecolheader = textBox6.Text;
            string alarmdescriptioncolheader = textBox7.Text;

            int MAXALARMS = 800; //what's the proper size for this?

            string[] alarms = new string[MAXALARMS];
            for (int i = 0; i < MAXALARMS; i++)
                alarms[i] = String.Empty;

            try
            {
                if (destmatchtext == "")
                    throw new FormatException("Destination Alarm Keyword field cannot be empty.");
                if (alarmnamecolheader == "")
                    throw new FormatException("Alarm Number column header field cannot be empty.");
                if (alarmdescriptioncolheader == "")
                    throw new FormatException("Alarm Description column header field cannot be empty.");
                if (!radioButton1.Checked && !radioButton2.Checked)
                    throw new FormatException("Language must be specified!");
                if (sourcepath == "" || destpath == "")
                    throw new FormatException("Source and Destination files must be selected!");

                sourceapp = new Excel.Application();
                sourcebook = sourceapp.Workbooks.Open(sourcepath);
                sourcesheet = sourcebook.ActiveSheet;

                textBox5.Text += "Source file opened\r\n";

                Excel.Range usedarea = sourcesheet.UsedRange;
                Excel.Range nameheadercell = usedarea.Find(alarmnamecolheader);

                if (nameheadercell == null)
                    throw new ArgumentException("Alarm Name header not found!");

                int namecolumn = nameheadercell.Column;
                Excel.Range descriptionheadercell = usedarea.Find(alarmdescriptioncolheader);

                if (descriptionheadercell == null)
                    throw new ArgumentException("Alarm Description header not found!");

                int descriptioncolumn = descriptionheadercell.Column;

                Excel.Range endcell = usedarea.End[Excel.XlDirection.xlDown];
                int endrow = endcell.Row;
                Excel.Range searcharea = usedarea.Range[(char)(namecolumn + 64) + "1", (char)(namecolumn + 64) + endrow.ToString()];

                textBox5.Text += "Parsing source file...\r\n";

                foreach (Excel.Range cell in searcharea)
                {
                    var cellval = cell.Value;
                    if (sourcematchtext != "")
                    {
                        if (cellval != null && cellval.ToString().Contains(sourcematchtext))
                        {
                            string substring = cellval.ToString();
                            int dotindex = substring.IndexOf('.');
                            int openbracketindex = substring.IndexOf('[');
                            int closebracketindex = substring.IndexOf(']');

                            int index = -1;

                            if (!issourcebitwise) //not bitwise indexing
                            {
                                substring = String.Join("", substring.Where(char.IsDigit));
                                index = Int32.Parse(substring);
                            }
                            else if (dotindex != -1 && openbracketindex != -1 && closebracketindex != -1) //all elements found
                            {
                                string arrayindexstring = substring.Substring(openbracketindex + 1, closebracketindex - openbracketindex - 1);
                                string bitindexstring = substring.Substring(dotindex + 1);

                                if (Int32.TryParse(arrayindexstring, out int arrayindex) & Int32.TryParse(bitindexstring, out int bitindex))
                                    index = arrayindex * 32 + bitindex;
                            }

                            int currow = cell.Row;
                            string desc = "";
                            var descval = usedarea.Range[(char)(descriptioncolumn + 64) + currow.ToString()].Value;
                            if (descval != null)
                                desc = descval.ToString();
                            if (index >= 0 && index < MAXALARMS)
                                alarms[index] = desc;
                        }
                    }
                    else
                    {
                        int alarmnum = 0;
                        if (cellval != null && int.TryParse(cellval.ToString(), out alarmnum)) //cell value is an integer
                        {
                            int currow = cell.Row;
                            //int alarmnum = Int32.Parse(celval.ToString());
                            string desc = "";
                            var descval = usedarea.Range[(char)(descriptioncolumn + 64) + currow.ToString()].Value;
                            if (descval != null)
                                desc = descval.ToString();
                            if (alarmnum >= 0 && alarmnum < MAXALARMS)
                                alarms[alarmnum] = desc;
                        }
                    }
                }

                sourcebook.Close();

                textBox5.Text += "Source file read\r\n";

                destapp = new Excel.Application();
                destbook = destapp.Workbooks.Open(destpath);
                destsheet = destbook.ActiveSheet;

                textBox5.Text += "Destination file opened\r\n";

                usedarea = destsheet.UsedRange;

                Excel.Range langheadercell = usedarea.Find(language + ".TXT");

                if (langheadercell == null)
                    throw new ArgumentException("Could not find language destination column!");

                int langcolumn = langheadercell.Column;

                Excel.Range keywordrange = destsheet.Range["A:A"];
                endcell = keywordrange.End[Excel.XlDirection.xlDown];
                keywordrange = destsheet.Range["A1", endcell];

                textBox5.Text += "Parsing destination file...\r\n";

                foreach (Excel.Range cell in keywordrange.Cells)
                {
                    var cellval = cell.Value;
                    if (cellval != null && cellval.ToString().Contains(destmatchtext))
                    {
                        int currow = cell.Row;

                        string cellstring = cellval.ToString();
                        string numstring = String.Join("", cellstring.Where(char.IsDigit));
                        int num = Int32.Parse(numstring);

                        if (num >= 0 && num < MAXALARMS)
                            usedarea.Range[(char)(langcolumn + 64) + currow.ToString()].Value = alarms[num];
                    }
                }

                destbook.Save();
                destbook.Close();

                textBox5.Text += "Destination file written\r\n";

                MessageBox.Show("Operation Complete");
            }
            catch (Exception ex)
            {
                textBox5.Text += "Process Failed\r\n";
                MessageBox.Show("Error:\n" + ex.Message + "\n" + ex.StackTrace);
                if (sourcebook != null)
                    sourcebook.Close();
                if (destbook != null)
                    destbook.Close();
            }
        }

        private void radioButton_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton button = sender as RadioButton;

            if (button == null)
                return;
            else if (button.Checked)
                language = button.Text;

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox box = sender as CheckBox;

            if (box.Checked)
                issourcebitwise = true;
            else
                issourcebitwise = false;
        }
    }
}
