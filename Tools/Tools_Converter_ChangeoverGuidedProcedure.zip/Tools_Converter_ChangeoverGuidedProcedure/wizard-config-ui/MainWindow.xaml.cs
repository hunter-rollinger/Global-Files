﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using wizard_config_ui.ProcedureStructure;
using wizard_config_ui.ProcedureStructure.Procedures;

namespace wizard_config_ui
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            InitializeComponent();
            sourceFile.Text = Properties.Settings.Default.sourceFilePath;
            destinationFolder.Text = Properties.Settings.Default.destrinationJsonProcedureFolder;
            ExcelSheetsToExclude.Text = Properties.Settings.Default.noProcedureSheets;
            destrinationImagesFolder.Text = Properties.Settings.Default.destrinationImagesFolder;
        }

        private void ConvertButton_Click(object sender, RoutedEventArgs e)
        {
            ConvertButton.IsEnabled = false;
            bool notAllConfigOk = false;

            try
            {
                if (File.Exists(sourceFile.Text))
                {
                    Properties.Settings.Default.sourceFilePath = sourceFile.Text;
                    Properties.Settings.Default.sourceFilePath = Properties.Settings.Default.sourceFilePath.Replace("\\", "/");
                }
                else
                    notAllConfigOk = true;
                if (Directory.Exists(destinationFolder.Text))
                {
                    Properties.Settings.Default.destrinationJsonProcedureFolder = destinationFolder.Text;
                    Properties.Settings.Default.destrinationJsonProcedureFolder = Properties.Settings.Default.destrinationJsonProcedureFolder.Replace("\\", "/");
                }
                else
                    notAllConfigOk = true;

                Properties.Settings.Default.noProcedureSheets = ExcelSheetsToExclude.Text;
                Properties.Settings.Default.destrinationImagesFolder = destrinationImagesFolder.Text;
                Properties.Settings.Default.destrinationImagesFolder = Properties.Settings.Default.destrinationImagesFolder.Replace("\\", "/");
                Properties.Settings.Default.Save();

                if (!notAllConfigOk)
                {
                    IPersisterProcedure persister = new PersisterGuidedProcedure();
                    string currentType = "";
                    string prefixFileName = "";
                    if (changeoverRadio.IsChecked.Value)
                    {
                        currentType = "COProcedure";
                        prefixFileName = "co_";
                    }
                    else if (guidedprocedureRadio.IsChecked.Value)
                    {
                        currentType = "GPProcedure";
                        prefixFileName = "GP_";
                    }

                    if (currentType != "")
                    {
                        List<Procedure> procedures = persister.ReadProcedures(Properties.Settings.Default.sourceFilePath, Properties.Settings.Default.destrinationImagesFolder, currentType);
                        persister.WriteProcedures(procedures, Properties.Settings.Default.destrinationJsonProcedureFolder, prefixFileName);
                        MessageBox.Show("Conversion Completed");
                    }
                    else
                    {
                        MessageBox.Show("Select at least one convertion type");
                    }
                }
                else
                {
                    MessageBox.Show("Conversion Failed");
                }

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.InnerException+"\n\n"+ex.StackTrace+"\n\n" + ex.Message + "\n\nConversion Failed");
            }
            ConvertButton.IsEnabled = true;
        }
    }
    }
