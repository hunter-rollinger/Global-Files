﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wizard_config_ui.ProcedureStructure;

namespace wizard_config_ui.Utils
{
    public class ExcelUtil
    {
        public OleDbConnection connection { get; set; }
        public OleDbDataReader oleDbDataReader { get; set; }
        public void OpenExcelFile(string fileName)
        {
            string con = string.Format("Provider=Microsoft.ACE.OLEDB.12.0; data source={0}; Extended Properties=Excel 12.0 Macro;", fileName);
            connection = new OleDbConnection(con);
            connection.Open();
        }
        public List<string> ListSheets(string path, string[] splittedString)
        {
            List<string> listSheets = new List<string>();

            string con = string.Format("Provider=Microsoft.ACE.OLEDB.12.0; data source={0}; Extended Properties=Excel 12.0 Xml;", path);
            OleDbConnection connection = new OleDbConnection(con);
            connection.Open();
            DataTable dt = new DataTable();
            dt = connection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
            foreach (DataRow item in dt.Rows)
            {
                listSheets.Add(item["TABLE_NAME"].ToString());
            }
            List<string> finalSheets = new List<string>();
            foreach (var x in listSheets)
            {
                string[] splitted = x.Split('$');
                if ((splitted[1] == "" || splitted[1] == "'") && !splittedString.Contains(splitted[0].Replace("'","")))
                {
                    finalSheets.Add(x);
                }
            }
            return finalSheets;
        }
        public List<string> ReadSingleLine()
        {
            List<string> currentLine = new List<string>();
            int i = 0;
            while (i < oleDbDataReader.FieldCount)
            {
                currentLine.Add(oleDbDataReader[i].ToString().Replace(Convert.ToChar(160).ToString(), " "));
                i++;
            }
            return currentLine;
        }
        
    }
}
