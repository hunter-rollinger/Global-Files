﻿using System;
using System.Linq;

namespace wizard_config.Utils
{
    public static class myUtils
    {
        public static string FirstCharToUpper(this string input)
        {
            if (input != null && input != "")
                return input.First().ToString().ToUpper() + input.Substring(1);
            else
                return "";
        }
    }
}
