﻿using System.Collections.Generic;
using wizard_config_ui.ProcedureStructure;
using wizard_config_ui.ProcedureStructure.Procedures;

namespace wizard_config_ui

{
    public interface IPersisterProcedure
    {
        List<Procedure> ReadProcedures(string path, string imagePath, string procedureType);
        Procedure ReadProcedure(string tableName0, string imagePath, string procedureType);
        void WriteProcedures(List<Procedure> procedures, string folderPath, string prefixFileName);
        void WriteProcedure(Procedure procedure, string folderPath, string prefixFileName);

    }
}
