﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using wizard_config_ui.ProcedureStructure;
using wizard_config.Utils;
using wizard_config_ui.Utils;
using wizard_config_ui.ProcedureStructure.Procedures;

namespace wizard_config_ui
{
    public class PersisterGuidedProcedure : IPersisterProcedure
    {
        private ExcelUtil ExcelUtil;

        public PersisterGuidedProcedure()
        {
            ExcelUtil = new ExcelUtil();
        }

        public List<Procedure> ReadProcedures(string path, string imagesBasicPath, string procedureType)
        {
            ExcelUtil.OpenExcelFile(path);
            List<string> noProcedureSheetsEdited = new List<string>();
            Properties.Settings.Default.noProcedureSheets.Split(',').ToList().ForEach(x => noProcedureSheetsEdited.Add(x.Trim()));
            List<string> sheets = ExcelUtil.ListSheets(path, noProcedureSheetsEdited.ToArray());
            List<Procedure> procedures = new List<Procedure>();
            foreach (var x in sheets)
            {
                procedures.Add(ReadProcedure(x, imagesBasicPath, procedureType));
            }
            return procedures;
        }

        public Procedure ReadProcedure(string procedureName, string imageBasicPath, string procedureType)
        {
            Type type = AppDomain.CurrentDomain.GetAssemblies()
                                   .SelectMany(x => x.GetTypes())
                                   .FirstOrDefault(x => x.Name == procedureType);
            Procedure procedure = (Procedure) Activator.CreateInstance(type);
            try
            {
                FillDictionaryTable("Skills",procedure);
                FillDictionaryTable("Tools", procedure);
            }
            catch (Exception ex) 
            {
                new Exception("Failed to read Skills/Tools sheets");
            }

            OleDbCommand command = new OleDbCommand("select * from [" + procedureName + "]", ExcelUtil.connection);
            ExcelUtil.oleDbDataReader = command.ExecuteReader();
            int i = 0;
            while (ExcelUtil.oleDbDataReader.Read())
            {
                List<string> currentLine = new List<string>();
                currentLine.AddRange(ExcelUtil.ReadSingleLine());
                procedure.FillLine(currentLine, imageBasicPath, procedureName);
                i++;
            }
            return procedure;
        }

        public void WriteProcedures(List<Procedure> procedures, string folderPath, string prefixFileName)
        {
            foreach (Procedure x in procedures)
            {
                WriteProcedure(x, folderPath, prefixFileName);
            }
        }

        public void WriteProcedure(Procedure procedure, string folderPath, string prefixFileName)
        {
            try
            {
                var serializerSettings = new JsonSerializerSettings();
                serializerSettings.ContractResolver = new CamelCaseExceptDictionaryKeysResolver();
                string ProcedureString = JsonConvert.SerializeObject(procedure, Formatting.Indented, serializerSettings);
                using (StreamWriter writetext = new StreamWriter(folderPath + prefixFileName + procedure.ProcedureNumber.PadLeft(4, '0') + ".json"))
                {
                    writetext.Write(ProcedureString);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void FillDictionaryTable(string tableName, Procedure procedure)
        {
            OleDbCommand skillsCommand = new OleDbCommand("select * from [" + tableName + "$]", ExcelUtil.connection);
            ExcelUtil.oleDbDataReader = skillsCommand.ExecuteReader();
            while (ExcelUtil.oleDbDataReader.Read())
            {
                List<string> currentLine = ExcelUtil.ReadSingleLine();
                procedure.FillLineDictionary(currentLine);
            }
        }

    }
}
