﻿using System.Collections.Generic;

namespace wizard_config_ui.ProcedureStructure
{
    public class Requirements
    {
        public Requirements()
        {
            Skills = new List<string>();
            Tools = new List<string>();
        }

        public List<string> Skills { set; get; }
        public List<string> Tools { set; get; }

    }
}