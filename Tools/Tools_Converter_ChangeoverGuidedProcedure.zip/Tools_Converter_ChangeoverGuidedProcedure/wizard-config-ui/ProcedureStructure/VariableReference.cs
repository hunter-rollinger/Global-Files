﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wizard_config_ui.ProcedureStructure
{
    public class VariableReference
    {
        public ValueVariableReference Value { get; set; }
        public string Name { get; set; }
        public string DiagramReference { get; set; }
        public VariableReference()
        {
            Value = new ValueVariableReference();
        }
    }
}
