﻿using System;
using System.Collections.Generic;
using System.Text;

namespace wizard_config_ui.ProcedureStructure
{
    public class Description
    {
        public string heading { get; set; }
        public string minor { get; set; }

    }
}
