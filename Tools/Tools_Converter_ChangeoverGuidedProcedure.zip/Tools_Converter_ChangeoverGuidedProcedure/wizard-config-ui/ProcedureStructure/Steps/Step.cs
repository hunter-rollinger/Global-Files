﻿using System;
using System.Collections.Generic;
using System.Text;

namespace wizard_config_ui.ProcedureStructure
{
    public class Step
    {
        public string Number { set; get; }

        public Description Description { set; get; }

        public Requirements Requirements { set; get; }

        public bool IsUnskippable { get; set; }

        public List<string> Media { set; get; }

        public Step()
        {
            Description = new Description();
            Requirements = new Requirements();
            Media = new List<string>();
        }
    }
}
