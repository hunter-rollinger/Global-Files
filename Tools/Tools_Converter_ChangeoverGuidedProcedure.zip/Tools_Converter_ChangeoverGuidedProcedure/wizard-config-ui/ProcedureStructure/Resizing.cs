﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using wizard_config_ui.ProcedureStructure.Overviews;

namespace wizard_config_ui.ProcedureStructure
{
    public class Resizing
    {
        public COOverview Overview { set; get; }
        public List<Step> Steps { set; get; }
        public Resizing()
        {
            Overview = new COOverview();
            Steps = new List<Step>();
        }
    }
}
