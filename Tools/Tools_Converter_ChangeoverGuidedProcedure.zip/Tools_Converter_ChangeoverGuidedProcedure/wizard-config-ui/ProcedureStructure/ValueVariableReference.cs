﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wizard_config_ui.ProcedureStructure
{
    public class ValueVariableReference
    {
        public string Path { get; set; }
        public string Name { get; set; }
    }
}
