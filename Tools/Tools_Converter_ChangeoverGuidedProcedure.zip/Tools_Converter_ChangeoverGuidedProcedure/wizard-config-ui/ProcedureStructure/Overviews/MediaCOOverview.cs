﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wizard_config_ui.ProcedureStructure.Overviews
{
    public class MediaCOOverview
    {
        public string Before { get; set; }
        public string After { get; set; }
    }
}
