﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wizard_config_ui.ProcedureStructure.Overviews
{
    public class COOverview : Overview
    {
        public MediaCOOverview Media { get; set; }

        public COOverview()
        {
            Media = new MediaCOOverview();
        }
    }
}
