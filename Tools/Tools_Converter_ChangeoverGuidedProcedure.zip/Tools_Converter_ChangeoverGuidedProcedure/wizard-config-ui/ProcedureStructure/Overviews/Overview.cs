﻿using System;
using System.Collections.Generic;
using System.Text;

namespace wizard_config_ui.ProcedureStructure
{
    public class Overview
    {
        public string Help { set; get; }
    }
}
