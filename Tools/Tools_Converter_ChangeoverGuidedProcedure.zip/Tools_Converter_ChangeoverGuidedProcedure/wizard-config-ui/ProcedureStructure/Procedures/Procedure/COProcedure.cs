﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Globalization;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using wizard_config.Utils;
using wizard_config_ui.ProcedureStructure.Steps;
using wizard_config_ui.Utils;

namespace wizard_config_ui.ProcedureStructure.Procedures
{
    [DataContract]

    public class COProcedure : Procedure
    {
        [DataMember(Order = 6)]
        public Resizing Resizing { get; set; }
        [DataMember(Order = 7)]
        public Test Test { get; set; }
        public COProcedure()
        {
            Test = new Test();
            Resizing = new Resizing();
        }
        public override void FillLine(List<string> currentLine, string imageBasicPath, string procedureName)
        {
            if (currentLine[4] == "Overview")
            {
                currentLine.Insert(0, procedureName.Replace("$", "").Replace("'", ""));
                FillGeneral(currentLine, imageBasicPath);
            }
            else if (currentLine[4].Contains("Warning"))
            {
                Test test = new Test();
                FillWarning(currentLine);

            }
            else if (currentLine[4].Contains("Test"))
            {
                Test test = new Test();
                FillTestStep(currentLine);
            }
            else
            {
                Step step = new VariableStep();
                if (currentLine.Exists(x => x != ""))
                {
                    FillStep(currentLine, imageBasicPath, step);
                    Resizing.Steps.Add(step);
                }
            }
        }
        public override void FillLineDictionary(List<string> cols)
        {
            if (cols[0] != "")
            {
                TextInfo textInfo = new CultureInfo("it-IT", false).TextInfo;
                Translations["it"]?.Add(cols[0], textInfo.ToTitleCase(cols[1].ToLowerInvariant()));
                Translations["en"]?.Add(cols[0], textInfo.ToTitleCase(cols[2].ToLowerInvariant()));
                Translations["de"]?.Add(cols[0], textInfo.ToTitleCase(cols[3].ToLowerInvariant()));
            }
        }
        private void FillGeneral(List<string> cols, string imageBasicPath)
        {
            ProcedureNumber = cols[0];
            Type = cols[1];
            Author = cols[2];
            CreationDate = cols[3];
            Version = cols[4];
            Description = "MAIN_INFO";
            Resizing.Overview.Help = "MAIN_INFO";
            Translations["it"]?.Add("MAIN_INFO", myUtils.FirstCharToUpper(cols[14].ToLowerInvariant()).Replace("Loto", "LOTO").Replace("loto", "LOTO"));
            Translations["en"]?.Add("MAIN_INFO", myUtils.FirstCharToUpper(cols[15].ToLowerInvariant()).Replace("Loto", "LOTO").Replace("loto", "LOTO"));
            Translations["de"]?.Add("MAIN_INFO", myUtils.FirstCharToUpper(cols[16].ToLowerInvariant()).Replace("Loto", "LOTO").Replace("loto", "LOTO"));
            try
            {
                Resizing.Overview.Media.Before = imageBasicPath + cols[10].Replace("\n","").Split(',')[0].Trim();
                Resizing.Overview.Media.After = imageBasicPath + cols[10].Replace("\n", "").Split(',')[1].Trim();
            }
            catch (Exception e) { }
        }
        private void FillStep(List<string> cols, string imageBasicPath, Step step)
        {
            step.Number = cols[4];
            step.Description.heading = "KEY_HEADING_" + cols[4].PadLeft(4, '0');
            step.Description.minor = "KEY_MINOR_" + cols[4].PadLeft(4, '0');
            if (cols[4] != "")
            {
                TextInfo textInfo = new CultureInfo("it-IT", false).TextInfo;
                Translations["it"]?.Add(step.Description.heading, textInfo.ToTitleCase(cols[10].ToLowerInvariant()).Replace("Loto", "LOTO"));
                Translations["en"]?.Add(step.Description.heading, textInfo.ToTitleCase(cols[11].ToLowerInvariant()).Replace("Loto", "LOTO"));
                Translations["de"]?.Add(step.Description.heading, textInfo.ToTitleCase(cols[12].ToLowerInvariant()).Replace("Loto", "LOTO"));
                Translations["it"]?.Add(step.Description.minor, myUtils.FirstCharToUpper(cols[13]));
                Translations["en"]?.Add(step.Description.minor, myUtils.FirstCharToUpper(cols[14]));
                Translations["de"]?.Add(step.Description.minor, myUtils.FirstCharToUpper(cols[15]));
            }
            if (cols[5] != "")
            {
                step.IsUnskippable = true;
            }

            step.Requirements.Skills.AddRange(Array.FindAll(cols[6].Split(','), x => x != ""));
            step.Requirements.Tools.AddRange(Array.FindAll(cols[7].Split(','), x => x != ""));

            if (cols[8] != "")
            {
                ExcelUtil ExcelUtil = new ExcelUtil();
                ExcelUtil.OpenExcelFile(Properties.Settings.Default.sourceFilePath);
                OleDbCommand skillsCommand = new OleDbCommand("select * from [Variables$]", ExcelUtil.connection);
                ExcelUtil.oleDbDataReader = skillsCommand.ExecuteReader();
                while (ExcelUtil.oleDbDataReader.Read())
                {
                    List<string> currentLine = ExcelUtil.ReadSingleLine();
                    if (currentLine[0].Equals(cols[8]))
                    {
                        FillVariableLineDictionary(currentLine, (VariableStep)step);
                    }
                }
            }

            foreach (var x in cols[9].Split(','))
            {
                step.Media.Add(imageBasicPath + x);
            }

        }
        private void FillTestStep(List<string> cols)
        {
            string currentTestStepKey = "KEY_" + cols[4].ToUpper();
            Test.Steps.Add(currentTestStepKey);
            if (cols[4] != "")
            {
                TextInfo textInfo = new CultureInfo("it-IT", false).TextInfo;
                Translations["it"]?.Add(currentTestStepKey, myUtils.FirstCharToUpper(cols[13]));
                Translations["en"]?.Add(currentTestStepKey, myUtils.FirstCharToUpper(cols[14]));
                Translations["de"]?.Add(currentTestStepKey, myUtils.FirstCharToUpper(cols[15]));
            }
        }
        private void FillWarning(List<string> cols)
        {
            Test.Description = "KEY_" + cols[4].Replace(" ","").ToUpper();
            if (cols[4] != "")
            {
                TextInfo textInfo = new CultureInfo("it-IT", false).TextInfo;
                Translations["it"]?.Add(Test.Description, myUtils.FirstCharToUpper(cols[13]));
                Translations["en"]?.Add(Test.Description, myUtils.FirstCharToUpper(cols[14]));
                Translations["de"]?.Add(Test.Description, myUtils.FirstCharToUpper(cols[15]));
            }
        }
        public void FillVariableLineDictionary(List<string> cols, VariableStep Step)
        {
            if (cols[0] != "")
            {
                TextInfo textInfo = new CultureInfo("it-IT", false).TextInfo;
                if (Translations["it"] != null && !Translations["it"].ContainsKey(cols[0]))
                {
                    Translations["it"]?.Add(cols[0], textInfo.ToTitleCase(cols[4].ToLowerInvariant()));
                    Translations["en"]?.Add(cols[0], textInfo.ToTitleCase(cols[5].ToLowerInvariant()));
                    Translations["de"]?.Add(cols[0], textInfo.ToTitleCase(cols[6].ToLowerInvariant()));
                }
                VariableReference variableReference = new VariableReference();
                variableReference.Name = cols[0];
                variableReference.Value.Name = cols[0];
                variableReference.Value.Path = "ns=4;s="+cols[1];
                variableReference.DiagramReference = cols[3];
                Step.Parameters.Add(variableReference);
            }
        }
    }
}
