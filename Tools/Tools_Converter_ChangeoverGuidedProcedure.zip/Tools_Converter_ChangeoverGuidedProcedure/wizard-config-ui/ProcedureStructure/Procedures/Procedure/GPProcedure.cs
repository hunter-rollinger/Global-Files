﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Runtime.Serialization;
using wizard_config.Utils;
using wizard_config_ui.ProcedureStructure.Procedures;

namespace wizard_config_ui.ProcedureStructure
{
    [DataContract]
    public class GPProcedure : Procedure
    {
        [DataMember(Order = 6)]
        public object LastExecuted { get; set; }
        [DataMember(Order = 7)]
        public object ExecCycleHours { get; set; }
        [DataMember(Order = 8)]
        public Boolean IsOneShot { get; set; }
        [DataMember(Order = 9)]
        public Overview Overview { set; get; }
        [DataMember(Order = 10)]
        public List<Step> Steps { set; get; }
        public GPProcedure()
        {
            Overview = new Overview();
            Steps = new List<Step>();
        }
        public override void FillLine(List<string> currentLine, string imageBasicPath, string procedureName)
        {
            if(currentLine[7] == "Overview")
            {
                currentLine.Insert(0,procedureName.Replace("$", "").Replace("'", ""));
                FillGeneral(currentLine);
            }
            else 
            {
                Step step = new Step();
                if (currentLine.Exists(x => x != ""))
                {
                    FillStep(currentLine, imageBasicPath, step);
                    Steps.Add(step);
                }
            }
        }
        public override void FillLineDictionary(List<string> cols)
        {
            if (cols[0] != "")
            {
                TextInfo textInfo = new CultureInfo("it-IT", false).TextInfo;
                Translations["it"]?.Add(cols[0], textInfo.ToTitleCase(cols[1].ToLowerInvariant()));
                Translations["en"]?.Add(cols[0], textInfo.ToTitleCase(cols[2].ToLowerInvariant()));
                Translations["de"]?.Add(cols[0], textInfo.ToTitleCase(cols[3].ToLowerInvariant()));
            }
        }
        private void FillGeneral(List<string> cols)
        {
            ProcedureNumber = cols[0];
            Type = cols[1];
            Author = cols[2];
            CreationDate = cols[3];
            Version = cols[4];
            try
            {
                if (cols[5] != "")
                {
                    LastExecuted = 0;
                    ExecCycleHours = int.Parse(cols[5]);
                }
                else if (cols[6] != "")
                {
                    LastExecuted = DateTime.Now.Subtract(TimeSpan.FromHours(4)).ToString("MM/dd/yyyy HH:mm:sszzzz");
                    ExecCycleHours = int.Parse(cols[6]);
                }
                else
                {
                    LastExecuted = "";
                }
            }
            catch(Exception ex)
            {
                new Exception( ex.Message );
            }

            IsOneShot = cols[7] != "" ? true : false; 
            Name = "MAIN_TITLE";
            TextInfo textInfo = new CultureInfo("it-IT", false).TextInfo;
            Translations["it"]?.Add("MAIN_TITLE", ProcedureNumber + "." +textInfo.ToTitleCase(cols[14].ToLowerInvariant()).Replace("Loto", "LOTO"));
            Translations["en"]?.Add("MAIN_TITLE", ProcedureNumber + "." +textInfo.ToTitleCase(cols[15].ToLowerInvariant()).Replace("Loto", "LOTO"));
            Translations["de"]?.Add("MAIN_TITLE", ProcedureNumber +"."+textInfo.ToTitleCase(cols[16].ToLowerInvariant()).Replace("Loto", "LOTO"));
            Description = "MAIN_INFO";
            Overview.Help = "MAIN_INFO";
            Translations["it"]?.Add("MAIN_INFO", myUtils.FirstCharToUpper(cols[17].ToLowerInvariant()).Replace("Loto", "LOTO").Replace("loto", "LOTO"));
            Translations["en"]?.Add("MAIN_INFO", myUtils.FirstCharToUpper(cols[18].ToLowerInvariant()).Replace("Loto", "LOTO").Replace("loto", "LOTO"));
            Translations["de"]?.Add("MAIN_INFO", myUtils.FirstCharToUpper(cols[19].ToLowerInvariant()).Replace("Loto", "LOTO").Replace("loto", "LOTO"));

        }
        private void FillStep(List<string> cols, string imageBasicPath, Step step)
        {
            step.Number = cols[7];
            step.Description.heading = "KEY_HEADING_" + cols[7].PadLeft(4, '0');
            step.Description.minor = "KEY_MINOR_" + cols[7].PadLeft(4, '0');
            if (cols[7] != "")
            {
                TextInfo textInfo = new CultureInfo("it-IT", false).TextInfo;
                Translations["it"]?.Add(step.Description.heading, textInfo.ToTitleCase(cols[13].ToLowerInvariant()).Replace("Loto", "LOTO"));
                Translations["en"]?.Add(step.Description.heading, textInfo.ToTitleCase(cols[14].ToLowerInvariant()).Replace("Loto", "LOTO"));
                Translations["de"]?.Add(step.Description.heading, textInfo.ToTitleCase(cols[15].ToLowerInvariant()).Replace("Loto", "LOTO"));
                Translations["it"]?.Add(step.Description.minor, myUtils.FirstCharToUpper(cols[16]));
                Translations["en"]?.Add(step.Description.minor, myUtils.FirstCharToUpper(cols[17]));
                Translations["de"]?.Add(step.Description.minor, myUtils.FirstCharToUpper(cols[18]));
            }
            if (cols[8] != "")
            {
                step.IsUnskippable = true;
            }
            step.Requirements.Skills.AddRange(Array.FindAll(cols[9].Split(','), x => x != ""));
            step.Requirements.Tools.AddRange(Array.FindAll(cols[10].Split(','), x => x != ""));
            foreach (var x in cols[12].Split(','))
            {
                step.Media.Add(imageBasicPath + x);
            }
        }
        
    }
}
