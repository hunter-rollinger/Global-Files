﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using wizard_config_ui.ProcedureStructure.Steps;

namespace wizard_config_ui.ProcedureStructure.Procedures
{
    [DataContract]
    public abstract class Procedure : GeneralStructure
    {
        [DataMember(Order = 0)]
        public string Name { get; set; }
        [DataMember(Order = 1)]
        public string Type { get; set; }
        [DataMember(Order = 2)]
        public string Author { get; set; }
        [DataMember(Order = 3)]
        public string Description { get; set; }
        [DataMember(Order = 4)]
        public string CreationDate { get; set; }
        [DataMember(Order = 5)]
        public string Version { get; set; }
        [DataMember(Order = 11)]
        public Dictionary<string, Dictionary<string, string>> Translations;
        [IgnoreDataMember]
        public string ProcedureNumber { get; set; }
        protected Procedure()
        {
            Translations = new Dictionary<string, Dictionary<string, string>>();
            Translations.Add("it", new Dictionary<string, string>());
            Translations.Add("en", new Dictionary<string, string>());
            Translations.Add("de", new Dictionary<string, string>());
        }
    }
}
