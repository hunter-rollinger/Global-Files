﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wizard_config_ui.ProcedureStructure.Procedures
{
    public abstract class GeneralStructure
    {
        public abstract void FillLine(List<string> currentLine, string imageBasicPath, string procedureName);
        public abstract void FillLineDictionary(List<string> cols);
    }
}
