﻿namespace wizard_config_ui.ProcedureStructure.Procedures
{
    public class keyalue
    {
        public string key { get; set; }
        public string value { get; set; }
    }
}