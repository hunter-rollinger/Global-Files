﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wizard_config_ui.ProcedureStructure.Procedures
{
    class LanguageDictionary : GeneralStructure
    {
        List<keyalue> fullDictionary = new List<keyalue>();

        public override void FillLine(List<string> currentLine, string imageBasicPath, string procedureName)
        {

                keyalue dizionarioLingua = new keyalue();
                fullDictionary.Add(dizionarioLingua);


            throw new NotImplementedException();
        }

        public override void FillLineDictionary(List<string> cols)
        {
            throw new NotImplementedException();
        }
    }
}
