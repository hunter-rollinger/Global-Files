﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wizard_config_ui.ProcedureStructure
{
    public class Test
    {
        public String Description { get; set; }
        public List<String> Steps { get; set; }
        public Test()
        {
            Steps = new List<string>();
        }
    }
}
